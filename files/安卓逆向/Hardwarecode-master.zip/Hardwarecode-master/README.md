# Hardwarecode
##  基于xposed 修改硬件信息   
*  1 加入了动态更新 不用每次更改完重启 
*  2  RootCloak隐藏了xposed自身痕迹 防止三方应用 检测作弊行为
*  3  更改位置过了百度 高德地图 腾讯以及三方应用请自行修改作用对象
*  4  修改了build TelephonyManager Display 里面大部分函数
*  5  总共改了近60个函数 如IMEI IMSI CPU GPS android id 手机号码 运营商 WIFI  分辨率 等等

    
## Modify hardware information based on xposed

* 1 added a dynamic update without having to change the reboot every time
* 2 RootCloak hidden xscreen own traces to prevent the tripartite application to detect cheating
* 3 change the location of the Baidu high German map Tencent and tripartite applications, please modify the role of objects
* 4 modified most of the functions in the build TelephonyManager Display
* 5 total changed nearly 60 functions such as IMEI IMSI CPU GPS android id mobile phone number operator WIFI resolution and so on
